<?php
class moto extends vehiculo
{
    private $sidecar;
    public function __contruct($mar, $mod, $pre, $sid)
    {
        parent::__contruct($mar, $mod, $pre);
        $this->sidecar = $sid;
    }

    function calcularImpuesto()
    {
        $extra = 0;
        if ($this->sidecar) {
            $extra = 50;
        }
        return ($this->precio * 21) / 100 + $extra;
    }

    function mostrarDetalles()
    {
        return ("
        <p>Detalles de la Moto</p>".
        parent::mostrarDetalles().
        "<p>Tiene sidecar:".$this->sidecar ? 'Si' : 'No'."</p>");
    }
}
