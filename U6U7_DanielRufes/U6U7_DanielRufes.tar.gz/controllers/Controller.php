<?php
include ('../models/DataBase.php');



include ('../views/vista.php')
?>