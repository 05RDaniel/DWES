<?php
header("Location: ./controllers/Controller.php")
?>